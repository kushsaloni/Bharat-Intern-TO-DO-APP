# To Do List
Simple Android To Do List App


[DOWNLOAD](todo.apk)


![Screenshot_20220304-205820](https://user-images.githubusercontent.com/63160825/156792449-bd9a9530-9bbf-4def-b541-c56f0a25acf4.jpg)
